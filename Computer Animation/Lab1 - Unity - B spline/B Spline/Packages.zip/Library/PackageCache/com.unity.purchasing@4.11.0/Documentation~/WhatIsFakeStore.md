# What is Fake Store?

Fake Store isn't a store that exists in production, it is used to tests your apps quickly inside the editor.
