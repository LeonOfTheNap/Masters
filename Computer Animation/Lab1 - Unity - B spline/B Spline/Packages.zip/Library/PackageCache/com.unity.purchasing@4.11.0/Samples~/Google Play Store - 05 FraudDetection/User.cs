using System;
namespace Samples.Purchasing.GooglePlay.FraudDetection
{
    [Serializable]
    public class User
    {
        public string AccountId;
        public string ProfileId;
    }
}
