## README - In-App Purchasing Sample Scenes - Initialize Unity Gaming Services

This sample showcases how to initialize [Unity Gaming Services](https://unity.com/solutions/gaming-services) using the [Services Core API](https://docs.unity.com/ugs-overview/services-core-api.html)

### Unity Gaming Services
Enabling Unity Gaming Services within your game will let the In-App Purchasing package send transaction analytics events through the new [Unity Analytics](https://unity.com/products/unity-analytics) service.
