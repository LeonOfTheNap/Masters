using System;
namespace Samples.Purchasing.AppleAppStore.FraudDetection
{
    [Serializable]
    public class User
    {
        public string Username;
    }
}
