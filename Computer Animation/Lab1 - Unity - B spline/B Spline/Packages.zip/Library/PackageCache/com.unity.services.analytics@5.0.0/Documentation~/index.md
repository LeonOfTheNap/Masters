# Unity Gaming Services Analytics SDK Documentation
Please consult the full manual on https://docs.unity.com/analytics/
